package PokerProfessor;

public class Toaster {
	
	Object[] a;

}
