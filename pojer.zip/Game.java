package PokerProfessor;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class Game{

	BigBrain bigBrain;
	long pot, currentBet,currentBetOrRaise,bigBlind,smallBlind;
	Random rand=new Random();
	String[]flop=new String[3];
	String[]board=new String[7];
	String turn,river,card,burn,gameState;
	String at="";
	Scanner sc=new Scanner(System.in);
	private int choice,action,gameStage;//, numPlayers;
	Deck deck;
	Player p;
	ArrayList<Player>players=new ArrayList<>();
	boolean notDone,handIsOver,isHumansTurn,midRoundOfBetting;
	boolean isDealt,isFlop,isTurn,isRiver,gameOver,everyoneFolded,isUserFolded;
	Timer tm=new Timer(true);

	public Game(Player[]players,long bigBlind,long smallBlind){
		System.out.println("NEW CONTTTTTT!!!!!!!!!!!=======================================");
		bigBrain=new BigBrain();
		deck=new Deck();
		deck.shuffleDeck();
	}
	
	public void startGame(){contGame();}
	
	public void deal(){
		for(int i=0;i<2;i++)
		for(Player p:players){p.isFolded=false;p.dealPlayer((String)deck.getCard());}
		gameState="preFlop";isDealt=true;
	}
	
	public void flop(){burn=deck.getCard();for(int i=0;i<=2;i++){flop[i]=(String)deck.getCard();}gameState="flop";}
	public void turn(){burn=(String)deck.getCard();turn=(String)deck.getCard();gameState="turn";}
	public void river(){burn=(String)deck.getCard();river=(String)deck.getCard();gameState="river";}
	public void doBlinds(Player p,long bet){
		
		//this next line would find how many digits in pot value
		//for proper display formatting of pot amount
		//char[]xx=new char[(int)Math.log10(pot)+1];
		//so when its displayed on screen the numbers dont change position for increase digits
		p.setPlayerBet(bet);p.setChips(p.getChips() - bet);
		pot+=bet;currentBet=bet;incAction();
	}
	
	private void resetCurrentBet(){currentBet=0;}
	private void resetAction(){action=0;}
	private void resetPRoundOfBetting(){notDone=true;for(Player p:players){p.resetPlayer();p.isDone=false;}}
	private void resetPot(){pot=0;}
	
	public void betOrRaise(Player player,long betOrRaise){
		player.setToastString("Raise");
		player.raised();
		for(Player p2:players)p2.isDone=false;
		/*for(int a=0;a<players.size();a++)
			if(a==player)players.get(a).isDone=true;
			else players.get(a).isDone = false;*/
		//p = players.get(player);
		p.raised();//signal player has raised
		player.isDone=true;
		player.setChips(player.getChips() - (betOrRaise-player.getPlayerBet()));
		pot+=(betOrRaise-player.getPlayerBet());
		currentBet=betOrRaise;
		player.setPlayerBet(betOrRaise);
		incAction();
	}
	
	public void fold(Player player){
		player.folded();
		player.resetToasting();
		player.isDone=true;
		player.isFolded=true;
		players.remove(player);
		//if(player.getID()==0)isUserFolded=true;
		if(action==players.size())action=0;
		if(players.size()==1)everyoneFolded=true;
	}
	public void call(Player player){
		player.called();
		player.setToastString("Call");
		player.isDone=true;
		player.setChips(player.getChips() - (currentBet-player.getPlayerBet()));
		// increase the pot by the call amount
		pot+=(currentBet-player.getPlayerBet());
		//show the players call is now good to go
		player.setPlayerBet(currentBet);
		incAction();
	}
	public void check(Player player){
		player.checked();
		player.setToastString("Check");
		player.isDone=true;incAction();
		}

	private boolean allPlayersAreDone(){
		int v=0;
		for(Player p:players){
			//uncomment me for developing System.out.println(p.name+" is done?>>" + p.isDone);
			if(p.isDone)v++;}
		if(v==players.size()){System.out.println("returning true" + p.isDone);return true;}
		else return false;
	}
	
	public void roundOfBetting(){
		//uncomment me for developing System.out.println("doing round");
		x:if(true){
				p=players.get(action);
				//uncomment me for developing System.out.println("\nAction is at "+action+":::"+players.size());
				//uncomment me for developing System.out.println("\n\ndoing round of betting --- doin "+p.getName());
			
				if(p.getID()==0&&!isUserFolded){
					//uncomment me for developing System.out.println("Human's turn");
					if(!p.isDone){
						//uncomment me for developing System.out.println("you are not done, breaking for you");
						at="Your Turn, current bet is "+currentBet;
						isHumansTurn=true;/*midRoundOfBetting=true;break x;*/}
					else{System.out.println("player is done apparently");}//incAction();}
				}
				
				else if(!p.isDone)
				{
					if(!p.hasWaited()){
						System.out.println(p.getName()+" not has waited");
						if(!p.isWaiting()){
							System.out.println(p.getName()+" is not waiting");
							p.startWaiting();
							int aa=rand.nextInt(5);if(aa==0)aa=1;
							p.setWaitTime(aa); 
							System.out.println(p.getWaitTime()+" wait time");
							break x;
						}
						else{if(p.getWaitTime()>0){
							System.out.println(p.getName()+" wait time >0");
							try{Thread.sleep(1000);p.decWaitTime();break x;} 
							catch(InterruptedException e){e.printStackTrace();}
						}else{
							System.out.println(p.getName()+" done waiting");
							p.resetWaiting();p.resetHasWaited();}
						}
					}
					at=players.get(action).getName()+" 's turn";
					//uncomment me for developing System.out.println("this guy is not done: "+p.getName());
				isHumansTurn=false;giveOptions(p);}
				else if(p.isDone){System.out.println("this guy IS done");incAction();}
		
				//uncomment me for developing System.out.println("\nAfterwards Action is at "+action);
				if(allPlayersAreDone()){System.out.println("all are done looks like, setting notDone to false");notDone=false;/*break x;*/}	
		}
	}

	
	public void contGame(){
		if(everyoneFolded)gameStage=5;
			if(gameStage==0){  
				//pre-flop
				if(!allPlayersAreDone())roundOfBetting();
				else{
					gameStage++;
					System.out.println("FLOPPP!!!!");
					flop();
					resetCurrentBet();
					resetAction();
					resetPRoundOfBetting();
					isFlop=true;
				}	
			}
			if(gameStage==1){  //flop
				if(!allPlayersAreDone())roundOfBetting();
				else{
					gameStage++;
					System.out.println("TURNNN!!!!");
					turn();
					resetCurrentBet();
					resetAction();
					resetPRoundOfBetting();
					isTurn=true;
				}
			}
			if(gameStage==2){  //turn
				if(!allPlayersAreDone())roundOfBetting();
				else{
					gameStage++;
					System.out.println("RIVVVERRRRR!!!!");
					river();
					resetCurrentBet();
					resetAction();
					resetPRoundOfBetting();
					isRiver=true;
				}
			}
			if(gameStage==3){  //river
				if(!allPlayersAreDone())roundOfBetting();
				else
					gameStage++;
			}
			if(gameStage==4){  //end
				showDown();
				endGame();	
				gameOver=true;
			}
			if(gameStage==5){//everyone folded
				players.get(0).winMoney(pot);
				System.out.println("Everyone fOlded trying to end");
				endGame();
				handIsOver=true;
				gameOver=true;
				//everyone else folded, give last player the pot, end game
			}
	}
	
	
	public void giveOptions(Player player){
		System.out.println("\nplayer bet of "+player.getName()+" is "+player.getPlayerBet());
		System.out.println("and current bet is "+currentBet);
		doCompDecision(player);//get computers decision on its turn
	}
	
	public void userAction(int ua){
		Player p=players.get(getHumanPosition());
		s:if(true){
		if(ua==1)
			if(p.getBet()<currentBet){at="you must call "+currentBet;break s;}
			else check(p);
		if(ua==2)
			if(currentBet>0&&p.getBet()-currentBet<0&&currentBet<=p.getChips())call(p);
			else {at="There is nothing to call";break s;}
		//should be disabling buttons that shouldn't be pressed
		if(ua==3){betOrRaise(p,10);at="you raised";}//todo: check if enough chips, get how much to raise
		if(ua==4){fold(p);at="you folded";isUserFolded=true;}
		}
	}
	
	public void doCompDecision(Player player){
		isHumansTurn=false;
		choice=getChoiceBigBrain(player);
		//player.setToastString(choice);
		switch(choice){
		case 1://call
			if (p.getPlayerBet()<currentBet) {
				if((currentBet-p.getPlayerBet())<=p.getChips()){
					call(player);
					//System.out.println(player.getName()+" Called");
				} else {
					//System.out.println("Sorry, you dont have enough to call");
					break;
				}
			} else {
				// else there is no bet to call, the players current bet is good
				//System.out.println("There is nothing for you to call.");
				giveOptions(player);
				break;
			}
			System.out.println("after call, current pot is " + pot);
			break;
		case 2://check
			check(player);
			System.out.println(p.getName()+" Checked");
			break;
		case 3://bet or raise
			if(p.getID()==0){
				betOrRaise(player, getAmountToBetOrRaise());
			} else {
				betOrRaise(player, bigBrain.getAmountToBetOrRaise());
			}
			System.out.println("Player "+p.getName()+" bet/raised");
			System.out.println("after bet/raise, current pot is "+pot);
			break;
		// fold
		case 4:
			System.out.println(p.getName() + " Folded");
			System.out.println("Before fold, current pot is " + pot);
			fold(player);
			break;
		default:
			break;
		}
	}

	public void showDown() {
		// compare hands
		at="Time for showdown !";
		for(Player g:players)
			System.out.println(g.toString());
		Object[][]pP=new Object[players.size()][7];
		for(int i=0;i<players.size();i++){
			pP[i][0]=players.get(i).getCard(0);
			pP[i][1]=players.get(i).getCard(1);
			for(int s=0;s<3;s++)pP[i][s+2]=flop[s];
			pP[i][5]=turn;pP[i][6]=river;
		}
		
		ArrayList<Object[]>winners=bigBrain.whoWins(pP);
		
		for(int g=0;g<winners.size();g++){
			System.out.println("Winner is Player "+players.get((int)winners.get(g)[0]).getName()
					+" with a "+winners.get(g)[6]);
			for(int i=1;i<6;i++)
			System.out.print(winners.get(g)[i]+", ");
			System.out.println();
			}
		
		long moneyForWinners=pot/winners.size();
		for(int j=0;j<winners.size();j++){
			System.out.println("chip count before of winner "+j+" is "+players.get((int)winners.get(j)[0]).getChips());//prints chips before win
			players.get((int)winners.get(j)[0]).winMoney(moneyForWinners);
			System.out.println("chip count after of winner "+j+" is "+players.get((int)winners.get(j)[0]).getChips());//prints chips after win
		}
	}

	
	public void endGame() {
		deck.resetDeckCount();
		for(Player i:players){i.setPlayerBet(0);i.clearHand();}
		deck.resetDeckCount();
	}
	private void addPCards(Player p){
		board[0]=p.getCard(0);
		board[1]=p.getCard(1);
	}
	private void addFlop(Player p){
		addPCards(p);
		board[2]=flop[0];
		board[3]=flop[1];
		board[4]=flop[2];
	}
	private void addTurn(Player p){
		addFlop(p);
		board[5]=turn;
	}
	private void addRiver(Player p){
		addTurn(p);
		board[6]=river;
	}

	private int getChoiceBigBrain(Player player) {
		int pos=0;
		board=new String[7];
		switch(gameStage){
			case 0:addPCards(player);break;
			case 1:addFlop(player);break;
			case 2:addTurn(player);break;
			case 3:addRiver(player);break;
			default:break;
		}
	
		for(int i=0;i<players.size();i++)
			if(players.get(i)==player)pos=i;
		int a=bigBrain
				.makeDecisionBasedOnAwesomeMathStuff(player,players,board,gameStage,pos,currentBet,
						bigBlind,smallBlind);
		return a;

	}
	private long getAmountToBetOrRaise(){return bigBrain.getAmountToBetOrRaise();}
	

	public String[] getPlayerCards() {
		//trying this to avoid possible thread/memory problems ive been experiencing
		String[]k=new String[2];
		for (Player i:players) {
			if(i.getID()==0) {
				k[0]=i.getCard(0);
				k[1]=i.getCard(1);
			}
		}
		return k;
	}
	
	public int getHumanPosition(){while(true){for(int i=0;i<players.size();i++)if(players.get(i).getID()==0)return i;}}
	public int getWhoeversTurn(){return players.get(action).getID();}
	public boolean isPTurn(){return isHumansTurn;}
	public String[]getFlop(){if(flop!=null)return flop;return new String[]{"back","back","back"};}
	public String getTurn(){if(turn!=null)return turn;return"back";}
	public String getRiver(){if(river!=null)return river;return"back";}
	private void incAction(){if(action<players.size()-1)action++;else action=0;}
	public boolean isGameOver(){at="Game is Over";return gameOver;}
	public long getPot(){return pot;}
	public char[]getPotSplit(){return String.valueOf(pot).toCharArray();}
	public String getActivityText(){return at;}
	public int getAction(){return action;}
	
	public void newGame(Player[] pla, long bigBlind,long smallBlind)
	{
			System.out.println("NEW GAME!!!!!!!!!!!=======================================");
		
		isDealt=false;isFlop=false;isTurn=false;isRiver=false;
		everyoneFolded=false;isUserFolded=false;
		players.clear();
		for(Player pl:pla)
		{
			System.out.println(pl.getName()+":::id::"+pl.getID());
			players.add(pl);
		}
		getHumanPosition();deck.shuffleDeck();
		deal();resetAction();resetCurrentBet();
		resetPRoundOfBetting();resetPot();
		doBlinds(players.get(0),smallBlind);
		doBlinds(players.get(1),bigBlind);
		currentBet=bigBlind;gameStage=0;gameOver=false;
	}


}